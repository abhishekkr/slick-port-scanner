portChk.jar is the executable code for checking Opened/Closed ports on any IPAddress reading data from a CSV file

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

Syntax::

java -jar portChk.jar <CSVFileName-with-relative-or-absolute-path>

eg:: java -jar portChk.jar C:\portNfo.csv

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

Sample CSV File {also a sample file is there in "sample_CSV_file_used" folder}

10.7.5.84,80,HTTP
10.7.65.1,3128,Squid_HTTP
10.7.65.1,3130,Squid_ICP
10.7.1.15,3128,Squid_HTTP
10.7.5.84,8080,Port8080


||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

Sample Output

>>if port# 80 is closed @IP: 1.2.3.4<<

Trying to open Port# 80
Unable to attach to PORT 80 @IP: 1.2.3.4

>>if port# 80 is open @IP: 1.2.3.4<<

Trying to open Port# 80
@1.2.3.4 :: HTTP<or any string mentioned in CSVFile>